var redis = require("redis"),
  client = redis.createClient();

client.on('connect', function() {
  console.log('we are in')
})


//client.set('movie:starwars', JSON.stringify({
//  title: "star wards",
//  rating: 10
//})
//)


client.get('movie:starwars', function(err, d) {
  if(err) throw err
  d = JSON.parse(d)
  console.log(d.title)
})
