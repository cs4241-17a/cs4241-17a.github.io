var http = require('http')
  , url = require("url")
  , redis = require("redis")
  , qs = require("querystring");

// connect to database
client = redis.createClient();

client.on("error", function (err) {
  console.log("Error " + err);
});

var server = http.createServer( function (req, res) {

  // handle POST
  var d = '';
  req.on('data', function(c) {
    d = d+c
  })
  req.on('end', function() {
    if(d != '') {
      var q = qs.parse(d)
      if(q.newmovie){
        client.set('movies:'+q.newmovie, JSON.stringify({
          title: q.newmovie,
          rating: 4
        }))
      }
    }
    d = ''
  })

  // query DATABASE
  var movies = []
  // get titles and ratings from redis
  client.keys('*', function(err, k) {
    k.forEach(function(m, i, A) {
      client.get(m, function(err, mdata) {
        mdata = JSON.parse(mdata)
        if(mdata.title)
          movies.push(mdata)
        if(i === A.length-1)
          buildPage(res, movies)
      })
    })
  })


});


function buildPage(res, movies) {
  res.writeHead(200, {"Content-Type": "text/html"});

  res.write("<html>");
  res.write("<body>");
  res.write("<h2>My current movies are</h2>");

  // bad error checking
  if(movies.length > 0) {
    movies.forEach(function(d) {
      if(d) {
        res.write("<p>" + d.title + " ; " + d.rating + "</p>");
      }
    });
  }

  res.write("<form method=\"post\">");
  res.write("<label for=\"newmovie\" > Add New Movie</label>");
  res.write("<input id=\"newmovie\" name=\"newmovie\" type=\"text\">");
  res.write("<button type=\"submit\">Submit</button>")
  res.write("</form>");

  res.write("</body>");
  res.write("</html>");
  res.end();
}

server.listen(8088);
console.log("Server is listening on 8088");
