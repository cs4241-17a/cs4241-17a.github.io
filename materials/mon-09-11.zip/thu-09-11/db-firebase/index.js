var firebase = require("firebase");

// Initialize Firebase
// NOTE I deleted this demo since I shared the key in class.
// Make a project on the Firebase website and get your own key if you want to test it out
var config = {
  apiKey: "asdf",
  authDomain: "cs4241-demo.firebaseapp.com",
  databaseURL: "https://cs4241-demo.firebaseio.com",
  projectId: "cs4241-demo",
  storageBucket: "cs4241-demo.appspot.com",
  messagingSenderId: "363312669919"
};
firebase.initializeApp(config);

writeUserData('123', 'lane', 'l@a.a', 'imgurl')

function writeUserData(userId, name, email, imageUrl) {
    firebase.database().ref('users/' + userId).set({
          username: name,
          email: email,
          profile_picture : imageUrl
        });
}
