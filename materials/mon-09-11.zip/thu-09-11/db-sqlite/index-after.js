var http = require('http')
  , url = require("url")
  , sqlite3 = require("sqlite3")
  , qs = require("querystring");

// connect to database
var db = new sqlite3.Database('movies.sqlite');

var server = http.createServer( function (req, res) {

  // handle POST
  var d = '';
  req.on('data', function(c) {
    d = d+c
  })
  req.on('end', function() {
    if(d != '') {
      var q = qs.parse(d)
      if(q.newclass){
        db.run("INSERT INTO movies VALUES ('"+ q.newclass +"', 5)");
      }
    }
    d = ''
  })

  // query DATABASE
  // todo
  var movies = []
  db.each("SELECT title, rating FROM movies", function(err, row) {
    movies.push( row )
  }, function() {
    buildPage(res, movies);
  })

//  then  buildPage(res, movies);
});

function buildPage(res, movies) {
  res.writeHead(200, {"Content-Type": "text/html"});

  res.write("<html>");

  res.write("<body>");

  res.write("<h2>My current movies are</h2>");

  // NOW movies looks like this:
  // [ { title: "Jaws", rating: 1}, ... ]
  movies.forEach(function(d) {
    res.write("<p>" + d.title + " ; " + d.rating + "</p>");
  });

  res.write("<form method=\"post\">");
  res.write("<label for=\"newclass\" > Add New Class</label>");
  res.write("<input id=\"newclass\" name=\"newclass\" type=\"text\">");
  res.write("<button type=\"submit\">Submit</button>")
  res.write("</form>");

  res.write("</body>");

  res.write("</html>");
  res.end();
}

server.listen(8088);
console.log("Server is listening on 8088");
