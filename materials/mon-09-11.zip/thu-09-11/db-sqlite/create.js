var sqlite3 = require('sqlite3');

// create database
var db = new sqlite3.Database('movies-17a.sqlite');

db.serialize(function() {

  // making the table
  db.run("CREATE TABLE movies (title varchar(100), rating integer)");

  // adding data
  db.run("INSERT INTO movies VALUES ('The Emoji Movie', 1)");
  db.run("INSERT INTO movies VALUES ('Guardians 2', 7)");
  db.run("INSERT INTO movies VALUES ('Wonder Woman', 10)");

  // querying data
  db.each("SELECT title, rating FROM movies", function(err, row) {
      console.log(row.title + ": " + row.rating);
  });

});

db.close();
