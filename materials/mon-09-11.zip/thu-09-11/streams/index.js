var http = require('http')
var fs = require('fs')


// sync
// DO NOTE USE UNLESS YOU HAVE TO
/*
var d = fs.readFileSync('all_sponsors.json')
console.log( d ) 
console.log( '---' ) 
console.log( JSON.parse(d) ) 
*/

// async
//var d = fs.readFile('all_sponsors.json', process_file);
//
//function process_file(err, d) {
//  console.log( d ) 
//  console.log( '---' ) 
//  console.log( JSON.parse(d) ) 
//}


var server = http.createServer(function(req, res) {
  var readstream = fs.createReadStream('all_sponsors.json');
  readstream.pipe( res );
}).listen(4241)

// stream
//var buf = ''
//readstream.on('data', function(d) {
//  buf += d
//});
//readstream.on('end', function(d) {
//  console.log(buf)
//});


/*

// Pipe

// TODO stream to response
//rs.pipe(res)

*/
